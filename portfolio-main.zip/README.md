# Portfolio
My GIS portfolio -> https://alanrocks.github.io/portfolio/ <br>
Welcome to my self-designed GIS portfolio, built with html, css, and JavaScript. It includes my photo, resume, professional experience, and my education background. Check it out below.

<img src="portfol_preview.png" alt="Portfolio preview" title="Portfolio preview">
